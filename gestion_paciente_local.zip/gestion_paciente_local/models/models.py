# -*- coding: utf-8 -*-

from odoo import models, fields


class Paciente(models.Model):
    _name = 'hospital.paciente'
    _description = 'Paciente'

    nombre = fields.Char(string="Nom i cognoms", required=True)
    sintomas = fields.Text(string="Símptomes")

class Medico(models.Model):
    _name = 'hospital.medico'
    _description = 'Metge'

    nombre = fields.Char(string="Nom i cognoms", required=True)
    num_colegiado = fields.Char(string="Número de col·legiat", required=True)

class Consulta(models.Model):
    _name = 'hospital.consulta'
    _description = 'Consulta'

    paciente_id = fields.Many2one('hospital.paciente', string="Pacient", required=True)
    medico_id = fields.Many2one('hospital.medico', string="Metge", required=True)
    diagnostico = fields.Text(string="Diagnòstic")
    fecha_consulta = fields.Datetime(string="Data de consulta", required=True)

