# -*- coding: utf-8 -*-
{
    'name': "Gestión Hospitalaria",
    'summary': "Módulo para gestionar pacientes y médicos en un hospital",
    'description': "Módulo de Odoo para gestionar pacientes, médicos y consultas en un hospital",
    'author': "Piero",
    'website': "https://hospital.example.com",
    'application': True,
    'category': 'Healthcare',
    'version': '1.0',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/hospital_views.xml',
    ]
}


