# -*- coding: utf-8 -*-
# from odoo import http


# class GestionPaciente(http.Controller):
#     @http.route('/gestion_paciente/gestion_paciente', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gestion_paciente/gestion_paciente/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('gestion_paciente.listing', {
#             'root': '/gestion_paciente/gestion_paciente',
#             'objects': http.request.env['gestion_paciente.gestion_paciente'].search([]),
#         })

#     @http.route('/gestion_paciente/gestion_paciente/objects/<model("gestion_paciente.gestion_paciente"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gestion_paciente.object', {
#             'object': obj
#         })

